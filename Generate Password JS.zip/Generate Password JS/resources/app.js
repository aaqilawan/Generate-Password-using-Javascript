//////////////////////////Generate///////////////////////////////////
// Lower Case abc is start from 97 (total 26)
function getRandomLower() {
	return String.fromCharCode(Math.floor(Math.random() * 26) + 97);
}
// Upper Case abc is start from 65 (total 26)
function getRandomUpper() {
	return String.fromCharCode(Math.floor(Math.random() * 26) + 65);
}
// Numbers is start from 48 (total 0-9)
function getRandomNumber() {
	return String.fromCharCode(Math.floor(Math.random() * 9) + 48);
}
// Symbols random
function getRandomSybmol() {
	let symbol = '/<>,.?#~]}[{@;:)(*&^%$£"!¬`';
	return symbol[Math.floor(Math.random() * symbol.length)];
}
////////////////////////////////////////////////////////////////

/////////////////////Function store in the object /////////////////////////////

let RandomNmber = {
	lower: getRandomLower,
	upper: getRandomUpper,
	number: getRandomNumber,
	symbol: getRandomSybmol
}

// DOM Start
let resultEl = document.getElementById('result');
let clipboardEl = document.getElementById('clipboard');
let lengthEl = document.getElementById('length');
let uppercaseEl = document.getElementById('uppercase');
let lowercasEl = document.getElementById('lowercase');
let numbersEl = document.getElementById('numbers');
let symbolsEl = document.getElementById('symbols');
let generateEl = document.getElementById('generate');

generateEl.addEventListener('click', () => {
	const hasLength = +lengthEl.value;
	const hasUppercase = uppercaseEl.checked;
	const hasLowercas = lowercasEl.checked;
	let hasNumbers = numbersEl.checked;
	let hasSymbol = symbolsEl.checked;

	resultEl.innerText = generatePassword(hasUppercase, hasLowercas, hasNumbers, hasSymbol, hasLength);
});

function generatePassword(lower, upper, number, symbol, length) {
	let generatePassword = '';
	let typeCount = lower + upper + number + symbol;
	let typeArr = [{
		lower
	}, {
		upper
	}, {
		number
	}, {
		symbol
	}].filter(
		item => Object.values(item)[0]
	);
	// Doesn't have a selected type
	if (typeCount === 0) {
		return '';
	}
	
	// Created the loop
	for (let i = 0; i < length; i += typeCount) {
		typeArr.forEach(type => {
			let funcName = Object.keys(type)[0];
			generatePassword += RandomNmber[funcName]();
		});
	}

	let finalResult = generatePassword.slice(0, length);
	return finalResult;
}
// clipboard copy 
clipboardEl.addEventListener('click', () => {
	const textarea = document.createElement('textarea');
	const password = resultEl.innerText;
	if (!password) {
		return;
	}
	textarea.value = password;
	document.body.appendChild(textarea);
	textarea.select();
	document.execCommand('copy');
	textarea.remove();
	alert('copy the current password');
});